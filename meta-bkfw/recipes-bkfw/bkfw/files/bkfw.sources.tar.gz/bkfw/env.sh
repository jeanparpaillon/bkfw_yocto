#!/bin/sh

BASEDIR=$(cd $(dirname ${BASH_SOURCE[0]}) && pwd)

DEFAULT_MIBS=SNMPv2-TCSNMPv2-MIB:IF-MIB:IP-MIBTCP-MIBUDP-MIBSNMP-VACM-MIB
MIBS=${DEFAULT_MIBS}:BKTEL-PHOTONICS-SMI:SMM-MIB
export MIBS

MIBDIRS=/usr/share/snmp/mibs/iana:/usr/share/snmp/mibs/ietf:${BASEDIR}/mibs
export MIBDIRS
