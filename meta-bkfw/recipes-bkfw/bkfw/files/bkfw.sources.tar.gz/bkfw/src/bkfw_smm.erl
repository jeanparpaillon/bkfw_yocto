%%%
%%% Monitor chassis
%%%
-module(bkfw_smm).
-author('jean.parpaillon@free.fr').

-behaviour(gen_server).

-include("bkfw.hrl").

%%%
%%% API
%%%
-export([start_link/0,
         get_smm/1,
         get_module/1,
         get_modules/0,
         get_slots/0]).

%% gen_server callbacks
-export([init/1,
         handle_call/3,
         handle_cast/2,
         handle_info/2,
         terminate/2,
         code_change/3]).

%% SNMP instrumentation
-export([variable_func/2]).

-define(PERIOD, 100).
-define(SLOTS, 128).
%%-define(TID, ?MODULE).

-define(MSGS, [read_n, read_it, read_a]).

%%%
%%% API
%%%
start_link() ->
  gen_server:start_link({local, ?MODULE}, ?MODULE, [], []).


get_module(I) ->
  gen_server:call(?MODULE, {get_module, I}).

get_modules() ->
  gen_server:call(?MODULE, get_modules).

get_slots() ->
  gen_server:call(?MODULE, get_slots).

get_smm(V) ->
  gen_server:call(?MODULE, {get_smm, V}).

%%% SNMP functions
variable_func(new, _) ->
  {value, ok};

variable_func(delete, _) ->
  {value, ok};

variable_func(get, Key) ->
	case gen_server:call(?MODULE, {get, Key}) of
    undefined -> {value, noSuchName};
		V when is_float(V) -> {value, round(V)};
		V when is_binary(V) -> {value, binary_to_list(V)};
		V -> {value, V}
	end.

%%
%% Callbacks
%%
init(_) ->
  ?info("Starting SMM monitoring", []),
	gen_event:add_handler(bkfw_alarms, bkfw_alarms_snmp, []),
  Slots = list_to_tuple(lists:duplicate(?SLOTS, false)),
  State0 = #{
    type => smm,
    slots => Slots,
    modules => #{},
    smmCurInternalTemp => 0.0,
    smmPowerSupply => 0.0
   },
  gen_server:cast(self(), read_infos),
  {ok, State0}.


handle_call({get, smmNumber}, _From, #{ modules := Modules }=S) ->
  {reply, maps:size(Modules), S};

handle_call({get, Key}, _From, S) ->
  {reply, maps:get(Key, S, undefined), S};

handle_call({get_module, I}, _From, #{ modules := Modules }=S) ->
  {reply, maps:get(I, Modules, undefined), S};

handle_call(get_modules, _From, #{ modules := Modules }=S) ->
  {reply, maps:values(Modules), S};

handle_call(get_slots, _From, #{ modules := Modules }=S) ->
  {reply, maps:keys(Modules), S};

handle_call({get_smm, 1}, _From, S) ->
  Ret = #{
    curInternalTemp => maps:get(smmCurInternalTemp, S, 0.0),
    powerSupply => maps:get(smmPowerSupply, S, 0.0),
    vendor => maps:get(smmVendor, S, <<>>),
    moduleType => maps:get(smmModuleType, S, <<>>),
    hwVer => maps:get(smmHWVer, S, <<>>),
    hwRev => maps:get(smmHWRev, S, <<>>),
    swVer => maps:get(smmSWVer, S, <<>>),
    fwVer => maps:get(smmFWVer, S, <<>>),
    partNum => maps:get(smmPartNum, S, <<>>),
    serialNum => maps:get(smmSerialNum, S, <<>>),
    productDate => maps:get(smmProductDate, S, <<>>),
    alarms => bkfw_alarms_srv:get(0)
   },
  {reply, Ret, S};

handle_call({get_smm, 2}, _From, S) ->
  Ret = [
         {serialnum,       maps:get(smmSerialNum, S, <<>>)},
         {partnum,         maps:get(smmPartNum, S, <<>>)},
         {date,            maps:get(smmProductDate, S, <<>>)},
         {vendor,          case maps:get(smmVendor, S, <<>>) of
                             <<"BKTel Photonics">> -> <<" Bktel\n      Photonics ">>;
                             <<"Laser 2000">> -> <<"   Laser 2000   ">>;
                             <<"Alnair">> -> <<"     Alnair     ">>;
                             <<"Infractive">> -> <<"   Infractive   ">>;
                             _ -> <<"vendor not\nconfigured">>
                           end},
         {hard,            maps:get(smmHWVer, S, <<>>)},
         {soft,            maps:get(smmSWVer, S, <<>>)},
         {alarms,          bkfw_alarms_srv:get(0)}
        ],
  {reply, Ret, S};

handle_call(_, _, S) ->
  {reply, ok, S}.


handle_cast(read_infos, S) ->
	Infos = application:get_env(bkfw, i, []),
  gen_server:cast(self(), {smm, ?MSGS}),
  {noreply, S#{
              smmVendor => get_info(vendor, Infos),
              smmModuleType => get_info(moduleType, Infos),
              smmHWVer => get_info(hwVer, Infos),
              smmHWRev => get_info(hwRev, Infos),
              smmSWVer => get_info(swVer, Infos),
              smmFWVer => get_info(fwVer, Infos),
              smmPartNum => get_info(partNum, Infos),
              smmSerialNum => get_info(serialNum, Infos),
              smmProductDate => get_info(productDate, Infos)
             }};

handle_cast({smm, []}, #{ modules := Modules }=S) ->
  gen_server:cast(self(), {modules, maps:keys(Modules)}),
  {noreply, S};

handle_cast({smm, [ Msg | Next ]}, S0) ->
  S = case handle_proto(Msg, S0) of
         {ok, S1} -> gen_server:cast(self(), {smm, Next}), S1;
         {error, timeout, S1} ->
           ?debug("SMM ~p timeout. Retrying in ~p ms~n", [Msg, 1000]),
           timer:apply_after(1000, gen_server, cast, [self(), {smm, [Msg|Next]}]),
           S1;
        {error, {string, Err}, S1} ->
          ?error("SMM error: ~s~n", [Err]),
          gen_server:cast(self(), {smm, [ Msg | Next]}),
          S1;
        {error, Err, S1} ->
          ?error("SMM error: ~p~n", [Err]),
          gen_server:cast(self(), {smm, [ Msg | Next ]}),
          S1
      end,
  {noreply, S};

handle_cast({modules, []}, S) ->
  timer:apply_after(
    application:get_env(bkfw, edfa_period, ?PERIOD),
    gen_server, cast, [self(), {smm, ?MSGS}]),
  {noreply, S};

handle_cast({modules, [ Idx | Next ]}, #{ modules := Modules }=S) ->
  Msgs = bkfw_mcu:init_proto(maps:get(Idx, Modules)),
  gen_server:cast(self(), {module, Msgs, Idx, Next}),
  {noreply, S};

handle_cast({module, [], Idx, Indices}, #{ modules := Modules }=S) ->
  Module = maps:get(Idx, Modules),
  {atomic, ok} = mnesia:transaction(
                   fun() ->
                       mnesia:write(bkfw_mcu:to_snmp(Module))
                   end),
  ok = lists:foreach(fun (Laser) ->
                         {atomic, ok} = mnesia:transaction(
                                          fun () -> mnesia:write(Laser) end)
                     end, bkfw_mcu:to_snmp_lasers(Module)),
  gen_server:cast(self(), {modules, Indices}),
  {noreply, S};

handle_cast({module, [ Msg | Next ], Idx, Indices}, #{ modules := Modules }=S0) ->
  Module0 = maps:get(Idx, Modules),
  S = case bkfw_mcu:handle_proto(Msg, Module0) of
        {ok, Module} ->
          gen_server:cast(self(), {module, Next, Idx, Indices}),
          S0#{ modules => Modules#{ Idx => Module }};
        {error, timeout} ->
          timer:apply_after(1000,
                            gen_server, cast, [self(), {smm, ?MSGS}]),
          S0;
        {error, Err} ->
					case Err of
						{string, E} -> ?error("Error monitoring AMP ~p: ~s~n", [Idx, E]);
						E when is_list(E) -> ?error("Error monitoring AMP ~p: ~s~n", [Idx, E]);
						E -> ?error("Error monitoring AMP ~p: ~p~n", [Idx, E])
					end,
          gen_server:cast(self(), {module, [], Idx, Indices}),
          S0#{ modules => Modules#{ Idx => Module0 }}
      end,
  {noreply, S}.


handle_info(_, S) ->
  {noreply, S}.


terminate(_Reason, _S) ->
  ok.


code_change(_, S, _) ->
  {ok, S}.


%%%
%%% Priv
%%%
handle_proto(read_it, S) ->
	case bkfw_srv:command(0, rit, []) of
		{ok, {0, it, [T, <<"C">>]}} when is_float(T); is_integer(T) ->
			{ok, S#{ smmCurInternalTemp => T}};
		{ok, Ret} ->
			{error, {string, io_lib:format("RIT invalid answer: ~p~n", [Ret])}, S};
		ok ->
			{error, {string, io_lib:format("RIT invalid answer: ok~n", [])}, S};
		{error, Err} ->
			{error, Err, S}
  end;

handle_proto(read_n, S) ->
  case bkfw_srv:command(0, rn, []) of
		{ok, {0, n, [Mask]}} when is_integer(Mask) ->
			handle_slots(Mask, 0, S);
		{ok, Ret} ->
			{error, {string, io_lib:format("RN invalid answer: ~p~n", [Ret])}, S};
		ok ->
			{error, {string, io_lib:format("RN invalid answer: ok~n", [])}, S};
		{error, Err} ->
			{error, Err, S}
  end;

handle_proto(read_a, S) ->
  case bkfw_srv:command(0, ra, []) of
		{ok, {0, alarms, Alarms}} ->
			handle_alarms(Alarms, S);
		{ok, Ret} ->
			{error, {string, io_lib:format("RA invalid answer: ~p~n", [Ret])}, S};
		ok ->
			{error, {string, io_lib:format("RA invalid answer: ok~n", [])}, S};
		{error, Err} ->
			{error, Err, S}
  end.


get_info(Key, Infos) ->
  case proplists:get_value(Key, Infos, <<>>) of
		<<>> -> <<>>;
		S when is_list(S) -> list_to_binary(S)
	end.


%% loop over all bits of mask and compare with old slots,
handle_slots(_Mask, ?SLOTS, S) ->
  {ok, S};

handle_slots(Mask, Idx, #{ modules := Modules0 }=S0)
  when Mask band (1 bsl Idx) == 0 ->
  mnesia:transaction(fun () -> mnesia:delete({ampTable, Idx+1}) end),
  S = S0#{ modules => maps:remove(Idx+1, Modules0) },
  handle_slots(Mask, Idx+1, S);

handle_slots(Mask, Idx, #{ modules := Modules }=S0)
  when Mask band (1 bsl Idx) /= 0 ->
  S = case maps:is_key(Idx+1, Modules) of
        false ->
          %% Amp was not there
          Amp = bkfw_mcu:new(Idx+1),
          mnesia:transaction(fun() ->
                                 mnesia:write(bkfw_mcu:to_snmp(Amp))
                             end),
          S0#{ modules => Modules#{ Idx+1 => Amp } };
        true ->
          %% Amp is already there
          S0
      end,
  handle_slots(Mask, Idx+1, S).


handle_alarms([], S) ->
  {ok, S};

handle_alarms([Name  | Tail], S) ->
  gen_event:notify(bkfw_alarms, #smmAlarm{ index=0, name=Name, obj=S }),
	bkfw_alarms_srv:set(0, Name),
  handle_alarms(Tail, S).
