-module(bkfw_mcu).
-author('jean.parpaillon@free.fr').

-include("bkfw.hrl").

-export([new/1,
         init_proto/1,
         handle_proto/2,
         to_snmp/1,
         to_snmp_lasers/1,
         get/2,
         set/3]).

%%% SNMP functions
-export([table_func/2,
         table_func/4]).

-define(PERIOD, 100).
-define(MSGS, [set_pw, read_pm, read_cc, read_gc, read_pc, read_mode,
               read_lt, read_lc, read_it, read_i, read_v, read_li,
               read_lo, read_a, read_limits_cc, read_limits_pc, read_limits_gc]).
-define(DEFAULT_CONFIG,
        #{
          type => "EDFA",
          'has_input_PD' => true,
          'has_output_PD' => true,
          'has_settable_LD1' => true,
          'number_of_laser' => 1
        }).


new(Idx) ->
	M0 = maps:merge(
         ?DEFAULT_CONFIG,
         maps:from_list(proplists:get_value(
                          Idx, application:get_env(bkfw, amps, []), []))),
  Type = ?to_binary(maps:get(type, M0)),
  M0#{
    index => Idx,
    type => Type,
    operatingMode => ?ampOperatingMode_off,
    lasers => new_lasers(Type, M0),
    powerPd => new_powerPd(Type, M0),
    password => maps:get(password, M0,
                         application:get_env(bkfw, amp_password, 0000)),
    auth => false,
    limits => #{ cc => #{}, gc => #{}, pc => #{} },
    'number_of_laser' => case Type of
                           <<"EDFA">> -> maps:get('number_of_laser', M0);
                           <<"RAMAN">> -> 2
                         end,
    'has_GC_mode' => case Type of
                       <<"EDFA">> -> maps:get('has_GC_mode', M0, true);
                       <<"RAMAN">> -> false
                     end,
    'has_PC_mode' => case Type of
                       <<"EDFA">> -> maps:get('has_PC_mode', M0, true);
                       <<"RAMAN">> -> true
                     end
   }.

new_powerPd(<<"EDFA">>, _) ->
  #{
     1 => #{ type => <<"Input power">> },
     2 => #{ type => <<"Output power">> }
   };
new_powerPd(<<"RAMAN">>, _) ->
  #{
     1 => #{ type => <<"Input power">> },
     2 => #{ type => <<"Output power">> },
     3 => #{ type => <<"Back reflexion">> }
   }.


new_lasers(Type, M) ->
  N = case Type of
        <<"EDFA">> -> maps:get('number_of_laser', M);
        <<"RAMAN">> -> 2
      end,
  lists:foldl(fun (I, Acc) ->
                  Acc#{ I => #{
                          index => I,
                          ampConsign => 0.0,
                          curTemp => 0.0,
                          curAmp => 0.0,
                          settable => if I == 1 ->
                                          maps:get('has_settable_LD1', M, true);
                                         true -> true
                                      end
                         }
                      }
              end, #{}, lists:seq(1, N)).

to_snmp(Amp) ->
  #ampTable{
     index = maps:get(index, Amp),
     type = to_snmp_type(maps:get(type, Amp)),
     gainConsign = ?access([gainConsign], Amp, 0.0),
     outputPowerConsign = ?access([outputPowerConsign, value], Amp, 0.0),
     operatingMode = ?access([operatingMode], Amp),
     curInternalTemp = ?access([curInternalTemp], Amp),
     powerPd1 = ?access([powerPd, 1, value], Amp, 0.0),
     powerPd2 = ?access([powerPd, 2, value], Amp, 0.0),
     powerPd3 = ?access([powerPd, 3, value], Amp, 0.0),
     powerSupply = ?access([powerSupply], Amp),
     inputLossThreshold = ?access([inputLossThreshold], Amp),
     outputLossThreshold = ?access([outputLossThreshold], Amp),
     pcMin = ?access([limits, pc, min, value], Amp, 0.0),
     pcMax = ?access([limits, pc, max, value], Amp, 0.0),
     gcMin = ?access([limits, gc, min, value], Amp, 0.0),
     gcMax = ?access([limits, gc, max, value], Amp, 0.0)
    }.

to_snmp_type(<<"EDFA">>) -> ?ampType_edfa;
to_snmp_type(<<"RAMAN">>) -> ?ampType_raman.


to_snmp_lasers(#{ index := Idx, lasers := Lasers }=M) ->
  lists:map(fun (LaserIdx) ->
                Laser = maps:get(LaserIdx, Lasers),
                #laserTable{
                   index = {Idx, LaserIdx},
                   ampConsign = maps:get(ampConsign, Laser),
                   curTemp = maps:get(curTemp, Laser),
                   ccMax = ?access([limits, cc, LaserIdx], M, 0.0)
                  }
            end, lists:sort(maps:keys(Lasers))).


get(M, 1) ->
  M#{
    alarms => bkfw_alarms_srv:get(maps:get(index, M))
   };

get(M, 2) ->
  [
   {index,               ?access([index], M)},
   {lasers,              ?access([lasers], M)},
	 {mode,                ?access([operatingMode], M)},
	 {min_pc,              ?access([limits, pc, min, value], M)},
	 {max_pc,              ?access([limits, pc, max, value], M)},
	 {min_gc,              ?access([limits, gc, min, value], M)},
	 {max_gc,              ?access([limits, gc, max, value], M)},
	 {number_of_laser,     maps:size(maps:get(lasers, M, #{}))},
	 {has_settable_LD1,    ?access(['has_settable_LD1'], M)},
	 {alarms,              bkfw_alarms_srv:get(maps:get(index, M))},
	 {input_power,         ?access([powerPd, 1, value], M)},
	 {output_power,        ?access([powerPd, 2, value], M)},
	 {internal_temp,       ?access([curInternalTemp], M)},
	 {'PC_setpoint',       ?access([outputPowerConsign], M)},
	 {'GC_setpoint',       ?access([gainConsign], M)},
	 {'has_PC_mode',       ?access(['has_PC_mode'], M)},
	 {'has_GC_mode',       ?access(['has_GC_mode'], M)},
	 {'has_input_PD',      ?access(['has_input_PD'], M)},
	 {'has_output_PD',     ?access(['has_output_PD'], M)}
  ].


set(Idx, Data, 1) ->
  Amp = bkfw_smm:get_module(Idx),
  case {maps:get(op, Data), maps:get(params, Data)} of
    {<<"setOperatingMode">>, [<<"4">>]} ->
			set_operating_mode(Idx, ?ampOperatingMode_off, Amp);
    {<<"setOperatingMode">>, [<<"3">>, Values]} ->
      Consigns = list_to_tuple(Values),
      lists:foldl(fun (_LaserIdx, {error, _}=Err) ->
                      Err;
                      (LaserIdx, ok) ->
                      C = ?to_float(element(LaserIdx, Consigns)),
                      set_operating_mode(Idx, {?ampOperatingMode_cc, LaserIdx, C}, Amp)
                  end, ok, maps:keys(maps:get(lasers, Amp)));
    {<<"setOperatingMode">>, [<<"2">>, C]} ->
      set_operating_mode(Idx, {?ampOperatingMode_gc, ?to_float(C)}, Amp);
    {<<"setOperatingMode">>, [<<"1">>, C]} ->
      set_operating_mode(Idx, {?ampOperatingMode_pc, ?to_float(C)}, Amp);
    {<<"setThresholds">>, [Input, Output]} ->
      set_thresholds(Idx, ?to_float(Input), ?to_float(Output));
    Cmd ->
      ?debug("Unknown command: ~p~n", [Cmd]),
      {error, internal}
  end;

set(Idx, Data, 2) ->
	F = fun (_, _, {error, _}=Err) ->
          Err;
          (mode, Mode, _Acc) ->
          set_operating_mode2(Idx, Mode);
          ('CC1_setpoint', V, _Acc) ->
          bkfw_srv:command(Idx, scc, [io_lib:format("~b ~.2f", [1, ?to_float(V)])]);
          ('CC2_setpoint', V, _Acc) ->
          bkfw_srv:command(Idx, scc, [io_lib:format("~b ~.2f", [2, ?to_float(V)])]);
          ('GC_setpoint', V, _Acc) ->
          bkfw_srv:command(Idx, sgc, [io_lib:format("~.2f", [?to_float(V)])]);
          ('PC_setpoint', V, _Acc) ->
          bkfw_srv:command(Idx, spc, [io_lib:format("~.2f", [?to_float(V)])]);
          (_, _, _Acc) ->
          {error, invalid_key}
      end,
	case maps:fold(F, ok, Data) of
		ok -> ok;
		{ok, _} -> ok;
		{error, _}=Err -> Err
	end.


%%% SNMP functions
table_func(new, NameDb) ->
  snmp_generic:table_func(new, NameDb);
table_func(delete, NameDb) ->
  snmp_generic:table_func(delete, NameDb).


table_func(is_set_ok, RowIndex, Cols, NameDb) ->
  snmp_generic:table_func(is_set_ok, RowIndex, Cols, NameDb);

table_func(set, RowIndex, Cols, NameDb) ->
  case set_from_snmp(RowIndex, Cols) of
		ok ->
			snmp_generic:table_func(set, RowIndex, Cols, NameDb);
		{error, _}=Err ->
      ?debug("Error setting SNMP variable: ~p~n", [Err]),
			genErr
  end;

table_func(get, RowIndex, Cols, NameDb) ->
  Vars = snmp_generic:table_func(get, RowIndex, Cols, NameDb),
  lists:map(fun ({value, V}) when is_float(V) ->
                {value, round(V)};
                ({value, V}) when is_binary(V) ->
                {value, binary_to_list(V)};
                ({value, V}) ->
                {value, V}
            end, Vars);

table_func(get_next, RowIndex, Cols, NameDb) ->
  case snmp_generic:table_func(get_next, RowIndex, Cols, NameDb) of
		[] -> [];
		Next when is_list(Next) ->
			lists:map(fun ({NextOID, NextValue}) when is_float(NextValue) ->
                    {NextOID, round(NextValue)};
                    ({NextOID, NextValue}) when is_binary(NextValue) ->
                    {NextOID, binary_to_list(NextValue)};
                    (Else) ->
                    Else
                end, Next);
		{genErr, Cols} ->
			{genErr, Cols}
  end;

table_func(Op, RowIndex, Cols, NameDb) ->
  snmp_generic:table_func(Op, RowIndex, Cols, NameDb).

%%%
%%% Internals
%%%
init_proto(#{ type := <<"EDFA">> }=M) ->
  P0 = [
        set_pw, read_pm, read_cc, read_mode,
        read_lt, read_lc, read_it, read_i, read_v, read_li,
        read_lo, read_a, read_limits_cc
       ],
  P1 = case maps:get('has_GC_mode', M) of
         true -> P0 ++ [read_gc, read_limits_gc];
         false -> P0
       end,
  case maps:get('has_PC_mode', M) of
    true -> P1 ++ [read_pc, read_limits_pc];
    false -> P1
  end;

init_proto(#{ type := <<"RAMAN">> }) ->
  [
   set_pw, read_pm, read_cc, read_pc, read_mode,
   read_lt, read_lc, read_it, read_i, read_v, read_li,
   read_lo, read_a, read_limits_cc, read_limits_pc
  ].


handle_proto(set_pw, #{ index := Idx, password := Passwd }=E) ->
  case bkfw_srv:command(Idx, spw, [integer_to_binary(Passwd)]) of
		{ok, {Idx, pwd, [ok]}} ->
			{ok, E#{ auth => true }};
		{ok, {Idx, pwd, [nok]}} ->
			?error("Authentication failed on amp #~b", [Idx]),
			{ok, E};
		{ok, _Ret} ->
			{error, {string, io_lib:format("SPW invalid answer: ~p~n", [_Ret])}};
		{error, Err} ->
			{error, Err}
  end;

handle_proto(read_cc, #{ index := Idx, lasers := Lasers0 }=E) ->
  F = fun(LaserIdx, Laser, {ok, Acc}) ->
          case bkfw_srv:command(Idx, rcc, [integer_to_binary(LaserIdx)]) of
            {ok, {Idx, cc, [_, A, <<"mA">>]}} when is_float(A); is_integer(A) ->
              {ok, Acc#{ LaserIdx => Laser#{ ampConsign => A } }};
            {ok, _Ret} ->
              {error, {string, io_lib:format("RCC invalid answer: ~p~n", [_Ret])}};
            {error, Err} -> {error, Err}
          end;
         (_, _, {error, Err}) -> {error, Err}
      end,
  case maps:fold(F, {ok, Lasers0}, Lasers0) of
    {ok, Lasers} -> {ok, E#{ lasers => Lasers }};
    {error, _}=Err -> Err
  end;

handle_proto(read_gc, #{ index := Idx }=E) ->
  case bkfw_srv:command(Idx, rgc, []) of
		{ok, {Idx, gc, [Y, <<"dB">>]}} when is_float(Y); is_integer(Y) ->
			{ok, E#{ gainConsign => Y }};
		{ok, _Ret} ->
			{error, {string, io_lib:format("RGC invalid answer: ~p~n", [_Ret])}};
		{error, Err} ->
			{error, Err}
  end;

handle_proto(read_pc, #{ index := Idx }=E) ->
  case bkfw_srv:command(Idx, rpc, []) of
		{ok, {Idx, pc, [Y, Unit]}} when is_float(Y); is_integer(Y) ->
			{ok, E#{ outputPowerConsign => #{ value => Y, unit => Unit }}};
		{ok, _Ret} ->
			{error, {string, io_lib:format("RPC invalid answer: ~p~n", [_Ret])}};
		{error, Err} ->
			{error, Err}
  end;

handle_proto(read_mode, #{ index := Idx }=E) ->
  case bkfw_srv:command(Idx, rmode, []) of
		{ok, {Idx, mode, [Mode]}} ->
			M = parse_mode(Mode),
			{ok, E#{ operatingMode => M}};
		{ok, _Ret} ->
			{error, {string, io_lib:format("RMODE invalid answer: ~p~n", [_Ret])}};
		{error, Err} ->
			{error, Err}
  end;

handle_proto(read_a, #{ index := Idx }=E) ->
  case bkfw_srv:command(Idx, ra, []) of
		{ok, {Idx, alarms, Alarms}} ->
			handle_alarms(Alarms, E);
		{ok, _Ret} ->
			{error, {string, io_lib:format("RA invalid answer: ~p~n", [_Ret])}};
		{error, Err} ->
			{error, Err}
  end;

handle_proto(read_lt, #{ index := Idx, lasers := Lasers0 }=E) ->
  F = fun(LaserIdx, Laser, {ok, Acc}) ->
          case bkfw_srv:command(Idx, rlt, [integer_to_binary(LaserIdx)]) of
            {ok, {Idx, lt, [_, T, <<"C">>]}} when is_float(T); is_integer(T) ->
              {ok, Acc#{ LaserIdx => Laser#{ curTemp => T} }};
            {ok, _Ret} ->
              {error, {string, io_lib:format("RLT invalid answer: ~p~n", [_Ret])}};
            {error, Err} ->
              {error, Err}
          end;
         (_, _, {error, Err}) ->
          {error, Err}
      end,
  case maps:fold(F, {ok, Lasers0}, Lasers0) of
    {ok, Lasers} -> {ok, E#{ lasers => Lasers }};
    {error, _}=Err -> Err
  end;

handle_proto(read_lc, #{ index := Idx, lasers := Lasers0 }=E) ->
  F = fun(LaserIdx, Laser, {ok, Acc}) ->
          case bkfw_srv:command(Idx, rlc, [integer_to_binary(LaserIdx)]) of
            {ok, {Idx, lc, [_, A, <<"mA">>]}} when is_float(A); is_integer(A) ->
              {ok, Acc#{ LaserIdx => Laser#{ curAmp => A } }};
            {ok, _Ret} ->
              {error, {string, io_lib:format("RLC invalid answer: ~p~n", [_Ret])}};
            {error, Err} ->
              {error, Err}
          end
      end,
  case maps:fold(F, {ok, Lasers0}, Lasers0) of
    {ok, Lasers} -> {ok, E#{ lasers => Lasers }};
    {error, _}=Err -> Err
  end;

handle_proto(read_it, #{ index := Idx }=E) ->
  case bkfw_srv:command(Idx, rit, []) of
		{ok, {Idx, it, [T, <<"C">>]}} when is_float(T); is_integer(T) ->
			{ok, E#{ curInternalTemp => T}};
		{ok, _Ret} ->
			{error, {string, io_lib:format("RIT invalid answer: ~p~n", [_Ret])}};
		{error, Err} -> {error, Err}
  end;

handle_proto(read_i, E) ->
	{ok, E};

handle_proto(read_pm, #{ index := Idx, powerPd := PowerPd0 }=E) ->
  case bkfw_srv:command(Idx, rpm, []) of
		{ok, {Idx, pd, Lines}} ->
			PowerPd = parse_pd(Lines, PowerPd0),
			{ok, E#{ powerPd => PowerPd }};
		{ok, _Ret} ->
			{error, {string, io_lib:format("RPM invalid answer: ~p~n", [_Ret])}};
		{error, Err} ->
			{error, Err}
  end;

handle_proto(read_v, #{ index := Idx }=E) ->
  case bkfw_srv:command(Idx, rv, []) of
		{ok, {Idx, v, [V, v]}} when is_float(V); is_integer(V) ->
			{ok, E#{ powerSupply => V}};
		{ok, _Ret} ->
			{error, {string, io_lib:format("RV invalid answer: ~p~n", [_Ret])}};
		{error, Err} ->
			{error, Err}
  end;

handle_proto(read_li, #{ index := Idx }=E) ->
  case bkfw_srv:command(Idx, rli, []) of
		{ok, {Idx, li, [Y, <<"dBm">>]}} ->
			{ok, E#{ inputLossThreshold => Y}};
		{ok, _Ret} ->
			{error, {string, io_lib:format("RLI invalid answer: ~p~n", [_Ret])}};
		{error, Err} ->
			{error, Err}
  end;

handle_proto(read_lo, #{ index := Idx }=E) ->
  case bkfw_srv:command(Idx, rlo, []) of
		{ok, {Idx, lo, [Y, <<"dBm">>]}} ->
			{ok, E#{ outputLossThreshold => Y}};
		{ok, _Ret} ->
			{error, io_lib:format("RLO invalid answer: ~p~n", [_Ret])};
		{error, Err} ->
			{error, Err}
  end;

% read_limits(#{ auth := false }=E) ->
% 	{ok, E};

handle_proto(read_limits_cc, #{ index := Idx, lasers := Lasers,
                                limits := Limits0 }=E) ->
  F = fun(LaserIdx, {ok, #{ cc := CCLimits }=Acc}) ->
          case bkfw_srv:command(Idx, rlcc, [integer_to_binary(LaserIdx)]) of
            {ok, {Idx, max, [_, _, A, <<"mA">>]}} when is_float(A); is_integer(A) ->
              {ok, Acc#{ cc => CCLimits#{ LaserIdx => A }}};
            {ok, Ret} ->
              {error, {string,
                       io_lib:format("RLCC ~b invalid answer: ~p~n", [LaserIdx, Ret])}};
            {error, Err} ->
              {error, Err}
          end
      end,
  case lists:foldl(F, {ok, Limits0}, maps:keys(Lasers)) of
    {ok, Limits} -> {ok, E#{ limits => Limits }};
    {error, _}=Err -> Err
  end;

handle_proto(read_limits_pc, #{ index := Idx, limits := Limits }=E) ->
  case bkfw_srv:command(Idx, rlpc, []) of
		{ok, {Idx, pc, [ [min, Min, Unit], [max, Max, _] ]}} ->
      {ok, E#{
             limits => Limits#{
                         pc => #{
                           min => #{ value => Min, unit => Unit },
                           max => #{ value => Max, unit => Unit }
                          }
                        }
             }};
		{ok, _Ret} ->
			{error, iolist_to_binary(io_lib:format("RLPC invalid answer: ~p~n", [_Ret]))};
		{error, Err} ->
			{error, Err}
  end;

handle_proto(read_limits_gc, #{ index := Idx, limits := Limits }=E) ->
  case bkfw_srv:command(Idx, rlgc, []) of
		{ok, {Idx, gc, [ [min, Min, Unit], [max, Max, _] ]}} ->
			{ok, E#{
             limits => Limits#{
                         gc => #{
                           min => #{ value => Min, unit => Unit },
                           max => #{ value => Max, unit => Unit }
                          }
                        }
            }};
		{ok, _Ret} ->
			{error, iolist_to_binary(io_lib:format("RLGC invalid answer: ~p~n", [_Ret]))};
		{error, Err} ->
			{error, Err}
  end.

%%%
%%% Convenience functions
%%%
parse_mode(pc) -> ?ampOperatingMode_pc;
parse_mode(gc) -> ?ampOperatingMode_gc;
parse_mode(cc) -> ?ampOperatingMode_cc;
parse_mode(off) -> ?ampOperatingMode_off.


parse_pd([], Acc) -> Acc;

parse_pd([ [Idx, P, Unit] | Tail], Pds) ->
  Pd = maps:get(Idx, Pds, #{}),
	parse_pd(Tail, Pds#{ Idx => Pd#{ value => P, unit => Unit } }).


handle_alarms([], E) -> {ok, E};
handle_alarms([Name  | Tail], E) ->
  Idx = maps:get(index, E),
  Alarm = #smmAlarm{ index=Idx, name=Name, obj=E },
  gen_event:notify(bkfw_alarms, Alarm),
	bkfw_alarms_srv:set(Idx, Name),
  handle_alarms(Tail, E).


set_from_snmp(_, []) ->
  ok;
set_from_snmp([Idx, LaserIdx], [{?laserAmpConsign, Val} | Tail]) when is_integer(Val) ->
  _ = bkfw_srv:command(Idx, scc, [io_lib:format("~b ~b.0", [LaserIdx, Val])]),
  set_from_snmp(Idx, Tail);
set_from_snmp([Idx], [{?ampGainConsign, Val} | Tail]) when is_integer(Val) ->
  _ = bkfw_srv:command(Idx, sgc, [io_lib:format("~b.0", [Val])]),
  set_from_snmp(Idx, Tail);
set_from_snmp([Idx], [{?ampOutputPowerConsign, Val} | Tail]) when is_integer(Val) ->
  bkfw_srv:command(Idx, spc, [io_lib:format("~b.0", [Val])]),
  set_from_snmp([Idx], Tail);
set_from_snmp([Idx], [{?ampOperatingMode, Val} | Tail]) ->
  case Val of
		?ampOperatingMode_off ->
			bkfw_srv:command(Idx, smode, [<<"OFF">>]),
			set_from_snmp(Idx, Tail);
		?ampOperatingMode_cc ->
			bkfw_srv:command(Idx, smode, [<<"CC">>]),
			set_from_snmp(Idx, Tail);
		?ampOperatingMode_gc ->
			bkfw_srv:command(Idx, smode, [<<"GC">>]),
			set_from_snmp(Idx, Tail);
		?ampOperatingMode_pc ->
			bkfw_srv:command(Idx, smode, [<<"PC">>]),
			set_from_snmp(Idx, Tail);
		_ ->
			{error, ?ampOperatingMode}
  end;
set_from_snmp(_Idx, [ Varbinds | _Tail ]) ->
  {error, {invalid, Varbinds}}.


set_operating_mode(Idx, ?ampOperatingMode_off, _Amp) ->
  bkfw_srv:command(Idx, smode, [<<"OFF">>]),
  ok;

set_operating_mode(Idx, {?ampOperatingMode_cc, N, V}, M) ->
  case ?access([lasers, N, settable], M, true) of
    true ->
      case ?access([limits, cc, N], M, 0.0) of
        Max when V > Max ->
          {error, ofr};
        _ ->
          case bkfw_srv:command(Idx, scc, [io_lib:format("~b ~.2f", [N, V])]) of
            {ok, {Idx, scc, [N, ofr]}} -> {error, ofr};
            _ -> bkfw_srv:command(Idx, smode, [<<"CC">>]), ok
          end
      end;
    false ->
      {error, unsettableLaser}
  end;

set_operating_mode(Idx, {?ampOperatingMode_gc, V}, M) ->
  case {?access([limits, gc, min, value], M, 0.0),
        ?access([limits, gc, max, value], M, 0.0)} of
    {Min, Max} when V > Max orelse V < Min ->
      {error, ofr};
    _ ->
      case bkfw_srv:command(Idx, sgc, [io_lib:format("~.2f", [V])]) of
        {ok, {Idx, sgc, [ofr]}} ->
          {error, ofr};
        _ ->
          bkfw_srv:command(Idx, smode, [<<"GC">>]),
          ok
      end
  end;

set_operating_mode(_Idx, {?ampOperatingMode_pc, V}, #{ pcMin := Min, pcMax := Max })
  when V > Max orelse V < Min ->
	{error, ofr};

set_operating_mode(Idx, {?ampOperatingMode_pc, V}, M) ->
  case {?access([limits, pc, min, value], M, 0.0),
        ?access([limits, pc, max, value], M, 0.0)} of
    {Min, Max} when V > Max orelse V < Min ->
      {error, ofr};
    _ ->
      case bkfw_srv:command(Idx, spc, [io_lib:format("~.2f", [V])]) of
        {ok, {Idx, spc, [ofr]}} ->
          {error, ofr};
        _ ->
          bkfw_srv:command(Idx, smode, [<<"PC">>]),
          ok
      end
  end;

set_operating_mode(_, {_, undefined}, _Amp) ->
	{error, missing_consign};

set_operating_mode(_, _, _Amp) ->
  {error, internal}.


set_operating_mode2(Idx, Mode) when is_binary(Mode) ->
	set_operating_mode2(Idx, binary_to_integer(Mode));

set_operating_mode2(Idx, ?ampOperatingMode_off) ->
	bkfw_srv:command(Idx, smode, [<<"OFF">>]);

set_operating_mode2(Idx, ?ampOperatingMode_cc) ->
	bkfw_srv:command(Idx, smode, [<<"CC">>]);

set_operating_mode2(Idx, ?ampOperatingMode_gc) ->
	bkfw_srv:command(Idx, smode, [<<"GC">>]);

set_operating_mode2(Idx, ?ampOperatingMode_pc) ->
	bkfw_srv:command(Idx, smode, [<<"PC">>]).


set_thresholds(_, undefined, _) -> {error, invalid_thresholds};
set_thresholds(_, _, undefined) -> {error, invalid_thresholds};
set_thresholds(Idx, Input, Output) ->
  case bkfw_srv:command(Idx, sli, [io_lib:format("~.2f", [Input])]) of
    {ok, {Idx, sli, _}} ->
      case bkfw_srv:command(Idx, slo, [io_lib:format("~.2f", [Output])]) of
        {ok, {Idx, slo, _}} ->
          ok;
        _ ->
          {error, internal}
      end;
    _ -> {error, internal}
  end.
