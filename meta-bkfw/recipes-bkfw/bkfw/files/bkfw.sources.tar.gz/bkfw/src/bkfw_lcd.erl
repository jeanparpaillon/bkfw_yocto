%%%-------------------------------------------------------------------
%%% @author Jean Parpaillon <jean.parpaillon@free.fr>
%%% @copyright (C) 2016, Jean Parpaillon
%%% @doc
%%%
%%% @end
%%% Created : 23 May 2016 by Jean Parpaillon <jean.parpaillon@free.fr>
%%%-------------------------------------------------------------------
-module(bkfw_lcd).

-behaviour(gen_server).

-include("bkfw.hrl").

%% API
-export([start_link/0,
         enabled/0]).

%% gen_server callbacks
-export([init/1, handle_call/3, handle_cast/2, handle_info/2,
         terminate/2, code_change/3]).

-define(SERVER, ?MODULE).
-define(SCRIPT, "roa.py").

start_link() ->
	?info("Start LCD controller", []),
	gen_server:start_link({local, ?SERVER}, ?MODULE, [], []).


enabled() -> os:find_executable(?SCRIPT) =/= false.


%%%
%%% gen_server callbacks
%%%
init([]) ->
	process_flag(trap_exit, true),
  timer:send_after(0, self(), open_port),
	{ok, false}.


handle_call(_Request, _From, State) ->
	Reply = ok,
	{reply, Reply, State}.


handle_cast(_Msg, State) ->
	{noreply, State}.

handle_info(open_port, _) ->
	RoaPath = os:find_executable(?SCRIPT),
	HttpOpts = application:get_env(bkfw, http, [{port, 80}]),
	Baseurl = iolist_to_binary(io_lib:format("http://localhost:~b", [proplists:get_value(port, HttpOpts, 80)])),
	Args = case bkfw_config:get_passwd() of
           undefined ->
             [ Baseurl ];
           {md5, Hash} ->
             [ Baseurl, "md5", Hash ]
         end,
	Port = open_port({spawn_executable, RoaPath}, [{args, Args}, exit_status]),
  {noreply, Port};

handle_info({Port, {exit_status, _}}, Port) ->
  timer:send_after(1000, self(), open_port),
	{noreply, false};

handle_info(_Info, State) ->
	{noreply, State}.


terminate(_Reason, _State) ->
	ok.


code_change(_OldVsn, State, _Extra) ->
	{ok, State}.

%%%
%%% Priv
%%%
