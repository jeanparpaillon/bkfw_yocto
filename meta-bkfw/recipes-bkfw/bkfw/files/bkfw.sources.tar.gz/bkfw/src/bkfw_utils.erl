-module(bkfw_utils).

-export([access/2,
         access/3,
         to_integer/1,
         to_float/1,
         to_binary/1]).

access(Keys, Map) ->
   access(Keys, Map, undefined).


access([ Key ], Map, Default) ->
  maps:get(Key, Map, Default);

access([ Key | Tail ], Map, Default) ->
  case maps:is_key(Key, Map) of
    true ->
      access(Tail, maps:get(Key, Map), Default);
    false ->
      Default
  end.

to_integer(undefined) -> undefined;
to_integer(V) when is_integer(V) -> V;
to_integer(V) when is_float(V) -> round(V);
to_integer(V) when is_binary(V) ->
  try binary_to_integer(V) of
      I -> I
  catch error:badarg ->
      undefined
  end.

to_float(undefined) -> undefined;
to_float(I) when is_float(I) ->	I;
to_float(I) when is_integer(I) ->	float(I);
to_float(I) when is_binary(I) ->
  try binary_to_float(I) of
      V -> V
  catch error:badarg ->
      try binary_to_integer(I) of
          V -> float(V)
      catch error:badarg ->
          undefined
      end
  end.

to_binary(V) when is_binary(V) -> V;
to_binary(V) when is_list(V) -> list_to_binary(V).
